Before running "feature-extraction-matlab.m", copy all the files from "FastIAC_25" and "Tools" into the same folder to import the library.
Those libraries are amazing, and some of them are from Morten. 

Find the 4 matrix to load on oneDrive: https://1drv.ms/u/s!AvEdekJz5Ii8i2rtoJxmwWeA1VGL
Thanks for Shahab and his powerful laptop.